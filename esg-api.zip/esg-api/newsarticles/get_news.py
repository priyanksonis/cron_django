from pygooglenewsscraper import GoogleNews

def get_all_news():

    #this is list of dictionaries of news  {"company_name": "","news_title": "","url": "","publisher": "","date": "","e": "r","s": "","g": ""}
    news_dic_list = []

    company_keyword = ['Nvidia Corporation','WNS','Taiwan Semiconductor Manufacturing','Texas Instruments','Broadcom Inc']

    for keyword in company_keyword:

        # google news object
        googlenews = GoogleNews(keyword = keyword)

        # perform google news search and retrieve raw news
        raw_news = googlenews.get_raw_news()

        # parse out the news articles
        news = googlenews.parse_news(html = raw_news.text)

        #only keep 20
        def keep_first_n_items(dictionary, n):
            # Get the keys of the first n items
            keys_to_keep = list(dictionary.keys())[:n]

            # Create a new dictionary with only the selected keys
            new_dictionary = {key: dictionary[key] for key in keys_to_keep}

            return new_dictionary

        news = keep_first_n_items(news, 20)


        # print out results
        for k, v in news.items():

            print(v['title'])
            print(v['url'])
            print(v['publisher'])
            print(v['date'])
            print()

        # Add a new 'score' key to each nested dictionary
        for news_v in news.values():
            news_v['score'] = 0.0

        for news_v in news.values():
            news_v['company_name'] = keyword

        news_dic_list.extend([news])

    print("done")
    return news_dic_list

