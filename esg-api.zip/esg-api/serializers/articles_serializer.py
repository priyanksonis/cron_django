from rest_framework import serializers
from esg_app.app_models.news_articles import NewsArticles


class ArticlesSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewsArticles
        fields = '__all__'
