from rest_framework import serializers
from esg_app.app_models.emission_transaction import EsgEmissionTransaction
from esg_app.app_models.units import EsgStaticUnits
from esg_app.app_models.metrics import EsgStaticMetrics
from esg_app.app_models.categories import EsgStaticCategories
from esg_app.app_models.client_transactions import EsgClientTransaction
from esg_app.app_models.vendor import EsgVendors


class EmissionDetailsSerializer(serializers.Serializer):
    emission_transaction_id = serializers.CharField()
    client_transaction_id = serializers.CharField()
    unit_name = serializers.CharField()
    quantity = serializers.IntegerField()
    category_name = serializers.CharField()
    factor_name = serializers.CharField()
    carbon_amount = serializers.DecimalField(max_digits=10,  decimal_places=6)
    emission_transaction_date = serializers.DateField()

class VendorCalculationSerializer(serializers.Serializer):
    vendor_id = serializers.CharField()
    vendor_name = serializers.CharField()
    client_transaction_date = serializers.CharField()
    country_name = serializers.CharField()
    category_details = serializers.ListField()
    vendor_domain_id_id = serializers.CharField()

class VendorCalculationSerializer1(serializers.Serializer):
    emission_list = serializers.DictField()

class ScopeAnalysisSerializer(serializers.Serializer):
    Month = serializers.DictField()
    emission_transaction_id = serializers.IntegerField()
    total_emission_amount = serializers.DecimalField(max_digits=10,  decimal_places=7)
    client_transaction_id = serializers.IntegerField()
    Scope_Analytics = serializers.DictField()