from rest_framework import serializers

class CompanySerializer(serializers.Serializer):
    company_id = serializers.CharField()
    company_domain = serializers.CharField()
    company_name = serializers.CharField()
    company_country = serializers.CharField()
    company_updated_date = serializers.DateTimeField()

