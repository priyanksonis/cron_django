from rest_framework import serializers
from esg_app.app_models.vendor import EsgVendors


class EsgVendorSerializer(serializers.Serializer):
    vendor_country = serializers.CharField()
    vendor_date = serializers.DateTimeField()
    vendor_id = serializers.CharField()
    vendor_name = serializers.CharField()
    vendor_details = serializers.DictField()
    vendor_domain = serializers.CharField()

class VendorSerializer(serializers.Serializer):
    vendor_list = serializers.DictField()
