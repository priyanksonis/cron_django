from rest_framework import serializers
from esg_app.app_models.mapping_activity import Masked_data

class SustainabilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Masked_data
        fields = ('invoice_supplier_name','material_description','spend_amount','currency','country','site','nace_activity','sustainability_score')