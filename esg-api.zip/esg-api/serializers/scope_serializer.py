from rest_framework import serializers
from esg_app.app_models.scope import EsgStaticScope

class ScopeCategorySerializer1(serializers.Serializer):
    scope_1 = serializers.DictField()


class ScopeCategorySerializer2(serializers.Serializer):
    scope_2 = serializers.DictField()


class ScopeCategorySerializer3(serializers.Serializer):
    scope_3 = serializers.DictField()

class EsgStaticScopeSerializer(serializers.ModelSerializer):
    class Meta:
        model = EsgStaticScope
        fields = '__all__'

class ScopeSerializer(serializers.Serializer):
    scope_list = serializers.DictField()

class ScopeCatSerializer(serializers.Serializer):
    scope_3 = serializers.DictField()

