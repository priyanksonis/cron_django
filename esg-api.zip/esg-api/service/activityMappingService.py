from repository.activityMapingRepo import sustainabilityActivity
from rest_framework import viewsets


class ActivityMappingSer:

    # def __init__(self):
    #     self.act_map = mappingActivity(viewsets.ViewSet)

    # def __init__(self):
    #     self.level = levelClasification(viewsets.ViewSet)

    def __init__(self):
        self.level = sustainabilityActivity(viewsets.ViewSet)