from repository.vendorRepository import VendorRepo
from rest_framework import viewsets


class VendorService:

    def __init__(self):
        self.company = VendorRepo(viewsets.ViewSet)