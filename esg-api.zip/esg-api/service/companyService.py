from repository.companyRepo import CompanyRepository
from rest_framework import viewsets


class CompanyService:

    def __init__(self):
        self.company = CompanyRepository(viewsets.ViewSet)