from repository.apiRepository import GetAccessToken, ApiAvarni
from rest_framework import viewsets

class ApiTokenService:

    def __init__(self):
        self.access_token = GetAccessToken(viewsets.ViewSet)

    def __init__(self):
        self.avarni_api = ApiAvarni(viewsets.ViewSet)