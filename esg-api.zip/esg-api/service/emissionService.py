from repository.emissionRepository import EmissionRepo
from rest_framework import viewsets


class EmissionService:

    def __init__(self):
        self.company = EmissionRepo(viewsets.ViewSet)