from rest_framework import viewsets
from rest_framework.views import APIView
from repository.authenticationRepository import UserAuthRepo, UserRepo

# Create your views here.

class AutheticationService:
    def __init__(self):
        self.register = UserAuthRepo(viewsets.ViewSet)

    def __init__(self):
        self.login = UserAuthRepo(viewsets.ViewSet)

    def __init__(self):
        self.user = UserRepo(APIView)

    def __init__(self):
        self.logout = UserAuthRepo(viewsets.ViewSet)