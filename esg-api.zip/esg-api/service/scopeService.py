from repository.scopeRepository import ScopeRepo
from rest_framework import viewsets


class ScopeService:

    def __init__(self):
        self.company = ScopeRepo(viewsets.ViewSet)