from repository.emailRepository import OTPRepo
from rest_framework.views import APIView


class EmailService:

    def __init__(self):
        self.otp = OTPRepo(APIView)