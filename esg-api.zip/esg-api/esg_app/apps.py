from django.apps import AppConfig


class EsgAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'esg_app'
