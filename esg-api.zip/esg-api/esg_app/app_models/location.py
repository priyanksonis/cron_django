import uuid
from django.db import models
from django.utils.translation import gettext_lazy as _
from .contries import EsgStaticContries

class EsgLocations(models.Model):
    location_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    address_line_1 = models.CharField(max_length=100, null=False)
    address_line_2 = models.CharField(max_length=100, null=False)
    country_id = models.ForeignKey(EsgStaticContries,on_delete=models.CASCADE,null=True)
    zipcode = models.CharField(max_length= 100,null=True)
    created_timestamp = models.DateTimeField(_('date created'), auto_now_add=True,null=True)
    updated_timestamp = models.DateTimeField(_('last updated'), auto_now=True, null=True)	
    is_deleted = models.BooleanField(default=False, null=True)
    is_active = models.BooleanField(default=True, null=True)