import uuid
from django.utils.translation import gettext_lazy as _
from django.db import models

class EsgStaticTransaction(models.Model):
    transaction_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction_type = models.CharField(max_length = 100, unique=True,null=True)
    created_timestamp = models.DateTimeField(_('date created'), auto_now_add=True,null=True)
    updated_timestamp = models.DateTimeField(_('last updated'), auto_now=True,null=True)	
    is_deleted = models.BooleanField(default=False,null=True)
    is_active = models.BooleanField(default=True,null=True)