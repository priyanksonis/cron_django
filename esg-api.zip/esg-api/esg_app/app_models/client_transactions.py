import uuid
from django.utils.translation import gettext_lazy as _
from django.db import models
from .transactions import EsgStaticTransaction
from .company import EsgCompanies
from .units import EsgStaticUnits
from .contries import EsgStaticContries
from .vendor import EsgVendors

class EsgClientTransaction(models.Model):
    client_transaction_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction_id = models.ForeignKey(EsgStaticTransaction,on_delete=models.CASCADE,null=True)
    company_id = models.ForeignKey(EsgCompanies,on_delete=models.CASCADE,null=True)
    client_transaction_date = models.DateTimeField(_('tractional_date'), auto_now=True, null=True)
    client_transaction_account_title = models.CharField(max_length=100, null=False)
    client_transaction_description = models.TextField(null=False)
    client_transaction_amount = models.DecimalField(blank=True, null=True, max_digits=10,  decimal_places=6)
    unit_id = models.ForeignKey(EsgStaticUnits,on_delete=models.CASCADE,null=True)
    country_id = models.ForeignKey(EsgStaticContries,on_delete=models.CASCADE,null=True)
    vendor_id = models.ForeignKey(EsgVendors,on_delete=models.CASCADE,null=True)
    created_timestamp = models.DateTimeField(_('date created'), auto_now_add=True,null=True)
    updated_timestamp = models.DateTimeField(_('last updated'), auto_now=True,null=True)	
    is_deleted = models.BooleanField(default=False,null=True)
    is_active = models.BooleanField(default=True,null=True)