import uuid
from django.utils.translation import gettext_lazy as _
from django.db import models
from .client_transactions import EsgClientTransaction
from .scope import EsgStaticScope
from .units import EsgStaticUnits
from .metrics import EsgStaticMetrics
from .categories import EsgStaticCategories
from .company_domain import EsgStaticCompanyDomain

class EsgEmissionTransaction(models.Model):
    emission_transaction_id = models.UUIDField(primary_key=True,default=uuid.uuid4, editable=False)
    client_transaction_id = models.ForeignKey(EsgClientTransaction,on_delete=models.CASCADE,null=True)
    scope_id = models.ForeignKey(EsgStaticScope,on_delete=models.CASCADE,null=True)
    vendor_domain_id = models.ForeignKey(EsgStaticCompanyDomain,on_delete=models.CASCADE,null=True)
    unit_id = models.ForeignKey(EsgStaticUnits,on_delete=models.CASCADE,null=True)
    quantity = models.IntegerField(null=True)
    category_id = models.ForeignKey(EsgStaticCategories,on_delete=models.CASCADE,null=True)
    factor_name = models.CharField(max_length=150)
    carbon_amount = models.DecimalField(blank=True, null=True, max_digits=10,  decimal_places=6)
    created_timestamp = models.DateTimeField(_('date created'), auto_now_add=True,null=True)
    updated_timestamp = models.DateTimeField(_('last updated'), auto_now=True,null=True)	
    is_deleted = models.BooleanField(default=False,null=True)
    is_active = models.BooleanField(default=True,null=True)


