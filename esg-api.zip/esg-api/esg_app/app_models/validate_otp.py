from django.db import models
from django.contrib.auth.models import User
from esg_app.app_models.esg_user import EsgUsers


class OTP_model(models.Model):
    user_id = models.ForeignKey(EsgUsers, on_delete=models.CASCADE, null=True,blank=True)
    otp = models.CharField(max_length=6)
    username = models.CharField(max_length=20, default=False)
    isValid = models.BooleanField(default=False)