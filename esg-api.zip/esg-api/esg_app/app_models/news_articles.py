from django.db import models
from django.utils.translation import gettext_lazy as _

class NewsArticles(models.Model):
    company_name = models.CharField(blank = True,max_length= 225,null=True)
    news_title = models.CharField(blank = True,max_length= 225,null=True)
    url = models.CharField(blank = True,max_length= 225,null=True)
    publisher = models.CharField(blank = True,max_length= 225,null=True)
    date = models.DateField(blank = True, null=True)
    e = models.CharField(blank = True,max_length= 225,null=True)
    s = models.CharField(blank = True,max_length= 225,null=True)
    g = models.CharField(blank = True,max_length= 225,null=True)