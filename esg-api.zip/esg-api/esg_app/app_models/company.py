import uuid
from django.utils.translation import gettext_lazy as _
from django.db import models
from .location import EsgLocations
from .company_domain import EsgStaticCompanyDomain

class EsgCompanies(models.Model):
    company_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    company_name = models.CharField(max_length=200, unique=True,null=True)
    company_domain_id = models.ForeignKey(EsgStaticCompanyDomain,on_delete=models.CASCADE,null=True)
    location_id = models.ForeignKey(EsgLocations,on_delete=models.CASCADE,null=True)
    created_timestamp = models.DateTimeField(_('date created'), auto_now_add=True,null=True)
    updated_timestamp = models.DateTimeField(_('last updated'), auto_now=True,null=True)	
    is_deleted = models.BooleanField(default=False,null=True)
    is_active = models.BooleanField(default=True,null=True)
