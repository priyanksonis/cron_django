import uuid
from django.db import models
from django.utils.translation import gettext_lazy as _
# from django.contrib.postgres.fields import HStoreField
# from django.contrib.postgres.operations import HStoreExtension
from .location import EsgLocations
from .company import EsgCompanies
from .company_domain import EsgStaticCompanyDomain
    

class EsgVendors(models.Model):
    vendor_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    vendor_name = models.CharField(max_length=100, unique = True,null=True)
    vendor_domain_id = models.ForeignKey(EsgStaticCompanyDomain,on_delete=models.CASCADE, null = True)
    location_id = models.ForeignKey(EsgLocations,on_delete=models.CASCADE,null=True)
    # vendor_questionaire = HStoreField()
    company_id = models.ForeignKey(EsgCompanies,on_delete=models.CASCADE)
    created_timestamp = models.DateTimeField(_('date created'), auto_now_add=True,null=True)
    updated_timestamp = models.DateTimeField(_('last updated'), auto_now=True,null=True)	
    is_deleted = models.BooleanField(default=False,null=True)
    is_active = models.BooleanField(default=True,null=True)
