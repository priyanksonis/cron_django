from django.db import models

class ChatDocModel(models.Model):
    uploaded_file = models.FileField(upload_to='uploads/')
    text = models.CharField(null = True, max_length=225, blank = True)