from django.db import models
from django.utils.translation import gettext_lazy as _
import uuid
from django.contrib.auth.models import User
from .company import EsgCompanies


class EsgUsers(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE,primary_key = False, null=True)
    esg_user_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    company_id = models.ForeignKey(EsgCompanies,on_delete=models.CASCADE,null=True)
    user_role = models.CharField(max_length=20,null=True)
    date_created = models.DateTimeField(_('date created'), auto_now_add=True,null=True)
    last_updated = models.DateTimeField(_('last updated'), auto_now=True,null=True)
    is_deleted = models.BooleanField(default=False,null=True)
    is_active = models.BooleanField(default=True,null=True)