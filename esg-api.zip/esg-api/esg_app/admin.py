from django.contrib import admin
from esg_app.app_models import mapping_activity
from esg_app.app_models import news_articles

@admin.register(mapping_activity.Masked_data)

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('gl_account',)

@admin.register(news_articles.NewsArticles)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ("company_name",)

