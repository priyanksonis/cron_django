from rest_framework import viewsets
from rest_framework.response import Response
from .app_models.contries import EsgStaticContries
from .app_models.categories import EsgStaticCategories
from .app_models.scope import EsgStaticScope
from .app_models.metrics import EsgStaticMetrics
from .app_models.units import EsgStaticUnits
from .app_models.company_domain import EsgStaticCompanyDomain
from .app_models.transactions import EsgStaticTransaction
from .app_models.location import EsgLocations
from .app_models.company import EsgCompanies
from .app_models.client_transactions import EsgClientTransaction
from .app_models.vendor import EsgVendors
from .app_models.emission_transaction import EsgEmissionTransaction
from rest_framework.views import APIView
from django.http import JsonResponse
from django.conf import settings
from rest_framework.response import Response
import json
from serializers.company_serializer import CompanySerializer



DB = settings.DB_FILE

class categoryAPI(viewsets.ViewSet):

    def company_api(self, request, format=None):
        with open(DB+"/company_api.json", mode = "r") as jFile:
            data = json.load(jFile)
            print(type(data))
            # filt = data['data']
            # print(filt)
        result = CompanySerializer(data).data
        return Response(result)


class CreateSchema(viewsets.ViewSet):
    
    def create_contry(self, request):
        country_name = request.data['country_name']
        country_code = request.data['country_code']
        currency = request.data['currency']

        country = EsgStaticContries(country_name=country_name,country_code=country_code,currency=currency)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    

    def create_category(self, request):
        category_name = request.data['category_name']

        country = EsgStaticCategories(category_name=category_name)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    

    def create_scope(self, request):
        scope_level = request.data['scope_level']

        country = EsgStaticScope(scope_level=scope_level)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    

    def create_metric(self, request):
        metrics_name = request.data['metrics_name']

        country = EsgStaticMetrics(metrics_name=metrics_name)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    

    def create_unit(self, request):
        unit_name = request.data['unit_name']

        country = EsgStaticUnits(unit_name=unit_name)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    

    def create_company_domain(self, request):
        company_domain_name = request.data['company_domain_name']

        country = EsgStaticCompanyDomain(company_domain_name=company_domain_name)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    
    def create_static_transaction(self, request):
        transaction_type = request.data['transaction_type']

        country = EsgStaticTransaction(transaction_type=transaction_type)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    
    def create_location(self, request):
        address_line_1 = request.data['address_line_1']
        address_line_2 = request.data['address_line_2']
        country_id = request.data['country_id']
        zipcode = request.data['zipcode']
        get_country = EsgStaticContries.objects.get(country_id = country_id)
        country = EsgLocations(address_line_1=address_line_1,address_line_2=address_line_2,country_id=get_country,
                               zipcode=zipcode)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    
    def create_company(self, request):
        company_name = request.data['company_name']
        company_domain_id = request.data['company_domain_id']
        print(company_domain_id,'Domain<-----------------------')
        location_id = request.data['location_id']
        print(location_id,'Location<-----------------------')
        
        get_location = EsgLocations.objects.get(location_id = location_id)
        get_company_domain = EsgStaticCompanyDomain.objects.get(company_domain_id = company_domain_id)
        
        country = EsgCompanies(company_name=company_name,company_domain_id=get_company_domain,
                               location_id=get_location)
        country.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    
    
    def create_client_transaction(self, request):
        transaction_id = request.data['transaction_id']
        company_id = request.data['company_id']
        client_transaction_date = request.data['client_transaction_date']
        account_title = request.data['client_transaction_account_title']
        description = request.data['client_transaction_description']
        amount = request.data['client_transaction_amount']
        unit_id = request.data['unit_id']
        country_id = request.data['country_id']
        vendor_id = request.data['vendor_id']
        get_transaction = EsgStaticTransaction.objects.get(transaction_id = transaction_id)
        get_company = EsgCompanies.objects.get(company_id=company_id)
        get_unit = EsgStaticUnits.objects.get(unit_id=unit_id)
        get_country = EsgStaticContries.objects.get(country_id=country_id)
        get_vendor = EsgVendors.objects.get(vendor_id=vendor_id)

        client_transaction = EsgClientTransaction(transaction_id=get_transaction,company_id=get_company,
                               client_transaction_date=client_transaction_date,client_transaction_account_title=account_title,
                               client_transaction_description=description,client_transaction_amount = amount,
                               unit_id=get_unit,country_id=get_country,vendor_id=get_vendor)
        client_transaction.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
       

    def create_vendor(self, request):
        vendor_name = request.data['vendor_name']
        vendor_domain = request.data['vendor_domain']
        location_id = request.data['location_id']
        vendor_questionaire = request.data['vendor_questionaire']
        company_id = request.data['company_id']
        get_location = EsgLocations.objects.get(location_id=location_id)
        get_company = EsgCompanies.objects.get(company_id=company_id)
        get_vendor_domain = EsgStaticCompanyDomain.objects.get(company_domain_id = vendor_domain)

        vendor = EsgVendors(vendor_name=vendor_name,vendor_domain_id=get_vendor_domain,
                                        location_id=get_location,vendor_questionaire=vendor_questionaire,
                                        company_id=get_company)
        vendor.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    
    def create_emission_tran(self, request):
        client_transaction_id = request.data['client_transaction_id']
        scope_id = request.data['scope_id']
        vendor_domain_id = request.data['vendor_domain_id']
        unit_id = request.data['unit_id']
        quantity = request.data['quantity']
        category_id = request.data['category_id']
        factor_name = request.data['factor_name']
        carbon_amount = request.data['carbon_amount']
        get_client_id = EsgClientTransaction.objects.get(client_transaction_id = client_transaction_id)
        get_scope = EsgStaticScope.objects.get(scope_id=scope_id)
        get_company_domain = EsgStaticCompanyDomain.objects.get(company_domain_id=vendor_domain_id)
        get_unit = EsgStaticUnits.objects.get(unit_id=unit_id)
        get_category = EsgStaticCategories.objects.get(category_id=category_id)

        emission = EsgEmissionTransaction(client_transaction_id=get_client_id,scope_id=get_scope,quantity=quantity,
                                        vendor_domain_id=get_company_domain,unit_id=get_unit,factor_name=factor_name,
                                        category_id=get_category,carbon_amount=carbon_amount)
        emission.save()

        response = Response()
        response.data  = {
            'message': 'Updated'
        }
        return response
    
