import requests
import json
from django.http import HttpResponse

token_endpoint = "https://prod-backend.avarni.co/api/token"
api_url = "https://prod-backend.avarni.co/api/calculate"

# access_token1 = None
# Replace the authorization key with the actual key
# auth_key = "eyJraWQiOiI4T1wvS0xXWWErbXU1WWJIRVJBZVRVYjRzc1RSUzRiYldETGFGUUhKYlwvM1k9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI2OWUzMmtjYjhzbzZjZDkwdGtwOGI4Y2I4OSIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoicHJvZHVjdFwvZGVsZXRlIHByb2R1Y3RcL3dyaXRlIHByb2R1Y3RcL3JlYWQiLCJhdXRoX3RpbWUiOjE2ODY3MjI0MjQsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC5hcC1zb3V0aGVhc3QtMi5hbWF6b25hd3MuY29tXC9hcC1zb3V0aGVhc3QtMl9uTGprc0VOZVYiLCJleHAiOjE2ODY3MjYwMjQsImlhdCI6MTY4NjcyMjQyNCwidmVyc2lvbiI6MiwianRpIjoiYjQwZjc0NDItZDRiNS00MjhlLThlNWItYjczYWZmNWExZGFlIiwiY2xpZW50X2lkIjoiNjllMzJrY2I4c282Y2Q5MHRrcDhiOGNiODkifQ.Za3BsIlS4qWUX6SR2eOs1BtdehcEGdSp7liZZvfX8BKXBJs8W7ZA9dfjjkFZeL8L_DZPGNhKP6Ee1BaoYcGV_HR6Oqd-sLNcGfc6q62oAsvSwykGs09_z16F4X1eWjsPdjKyNp44OMUTHtkpHne22n1BMeiwhKi5ftskVDkp9rZaHyp_o2AkzDm5utISLZQBBqabW04242VDg8yqAUFCtM4n6iFJ6al0jyewh9VNZXvBaOzzfywLoabPJzGUNkvw0u_keinzMJ_yyOZKtPMMHZX0iw9Z2Li47K5eYloeKP5w6eRmVaY1ILySdPKGQzBX-qAgGVknMB-2-xcjTO3p9g"

key1 = "Basic NjllMzJrY2I4c282Y2Q5MHRrcDhiOGNiODk6bnA1ZHNlcm9ocTdiOG8wNWltMjRpcmV0c2NuazhuZmNnNjBqdDcwbHQ3dDhja3UzbDM3"

json_body = []
for _ in range(0,2):
    json_body2 ={
            "transactionId": "ec9bfb7a-8c8e-45d1-ae06-aaadc89c09f8",
            "account": "Catering Services",
            "vendor": "McDonald's",
            "amount": 10,
            "currency": "USD",
            "country": "united states",
            "factor_source":"EPA"
        }
    json_body.append(json_body2)
        
json_body_str = json.dumps(json_body)

    # Set the headers for the request, including the authorization key and the content type
# headers = {
#   "Authorization": f"Bearer {auth_key}",
#   "Content-Type": "application/json"
# }
proxy = {"http" : "http://127.0.0.1:8000/"}

basic_headers = {
  "Authorization": key1,
  "Content-Type": "application/json"
}
