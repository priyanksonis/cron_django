# import pandas as pd
# import random
# from django.conf import settings
# import json

# DB = settings.MAPPING_FILE

# match = False

# input_df_dic = {
#             "Invoice_Supplier_Name" : [],
#             "WNS_Normalized_Vendor_Name" : [],
#             "GL_Account" : [],
#             "GL_Account_mask_alphanumeric" : [],
#             "GL_Account_mask_numeric" : [],
#             "Material_Description" : [],
#             "Material_Description_translated" : [],
#             "Material_Group_Description" : [],
#             "GL_Account_Description" : [],
#             "Concatenate_translated" : [],
#             "Concatenate" : [],
#             "Invoice_Supplier_Number" : [],
#             "Invoice_Supplier_no_mask_alphanumeric" : [],
#             "Invoice_Currency" : [],
#             "Currency" : [],
#             "Spend_Amount" : [],
#             "Spend_amt" : [],
#             "Invoice_Supplier_Country" : [],
#             "Country" : [],
#             "Activity" : [],
#             "Sector" : [],
#             "Activity number" : []
#         }

# def mapping():
#     global match, input_df_dic
#     df_input = pd.read_excel(DB+'/Avarni_data_masked_toy.xlsx')

#     num1 = random.randint(0, len(df_input)-1)
#     num1 = 20
#     print(num1)

#     # df_input_row =  df_input.iloc[[num1]]
#     # print(df_input_row)

        
#     s = ""
#     if pd.isnull(df_input.iloc[num1, df_input.columns.get_loc('Material_Description')]):
#         pass
#     else:
#         s = s + str(df_input.loc[num1, 'Material_Description']) + ' '

#     if pd.isnull(df_input.iloc[num1, df_input.columns.get_loc('Material_Group_Description')]):
#         pass
#     else:
#         s = s + str(df_input.loc[num1, 'Material_Group_Description']) + ' '

#     if pd.isnull(df_input.iloc[num1, df_input.columns.get_loc('GL_Account_Description')]):
#         pass
#     else:
#         s = s + str(df_input.loc[num1, 'GL_Account_Description'])

    

#     input_df_dic['Invoice_Supplier_Name'].append(df_input.loc[num1, "Invoice_Supplier_Name"])
#     input_df_dic['WNS_Normalized_Vendor_Name'].append(df_input.loc[num1, "WNS_Normalized_Vendor_Name"])
#     input_df_dic['GL_Account'].append(df_input.loc[num1, "GL_Account"])
#     input_df_dic['GL_Account_mask_alphanumeric'].append(df_input.loc[num1, "GL_Account_mask_alphanumeric"])
#     input_df_dic['GL_Account_mask_numeric'].append(df_input.loc[num1, "GL_Account_mask_numeric"])
#     input_df_dic['Material_Description'].append(df_input.loc[num1, "Material_Description"])
#     input_df_dic['Material_Description_translated'].append("")
#     input_df_dic['Material_Group_Description'].append(df_input.loc[num1, "Material_Group_Description"])
#     input_df_dic['GL_Account_Description'].append(df_input.loc[num1, "GL_Account_Description"])
#     input_df_dic['Concatenate_translated'].append("")
#     input_df_dic['Concatenate'].append(df_input.loc[num1, "Concatenate"])
#     input_df_dic['Invoice_Supplier_Number'].append(df_input.loc[num1, "Invoice_Supplier_Number"])
#     input_df_dic['Invoice_Supplier_no_mask_alphanumeric'].append(df_input.loc[num1, "Invoice_Supplier_no_mask_alphanumeric"])
#     input_df_dic['Invoice_Currency'].append(df_input.loc[num1, "Invoice_Currency"])
#     input_df_dic['Currency'].append(df_input.loc[num1, "Currency"])
#     input_df_dic['Spend_Amount'].append(df_input.loc[num1, "Spend_Amount"])
#     input_df_dic['Spend_amt'].append(df_input.loc[num1, "Spend_amt"])
#     input_df_dic['Invoice_Supplier_Country'].append(df_input.loc[num1, "Invoice_Supplier_Country"])
#     input_df_dic['Country'].append(df_input.loc[num1, "Country"])

#     df_ref = pd.read_excel(DB+'/reference_table.xlsx')

#     # match = False

#     for i in range(len(df_ref)):

#         s_ref = ""
#         if pd.isnull(df_ref.iloc[i, df_ref.columns.get_loc('Material_Description')]):
#             pass
#         else:
#             s_ref = s_ref + str(df_ref.loc[i, 'Material_Description']) + ' '

#         if pd.isnull(df_ref.iloc[i, df_ref.columns.get_loc('Material_Group_Description')]):
#             pass
#         else:
#             s_ref = s_ref + str(df_ref.loc[i, 'Material_Group_Description']) + ' '

#         if pd.isnull(df_ref.iloc[i, df_ref.columns.get_loc('GL_Account_Description')]):
#             pass
#         else:
#             s_ref = s_ref + str(df_ref.loc[i, 'GL_Account_Description'])

#         if s.lower().lstrip().rstrip() == s_ref.lower().lstrip().rstrip():
#             match = True
#             print("match::")

#             print(df_ref.loc[i, "Activity"])

#             input_df_dic['Activity'].append(df_ref.loc[i, "Activity"])
#             input_df_dic['Sector'].append(df_ref.loc[i, "Sector"])
#             input_df_dic['Activity number'].append(df_ref.loc[i, "Activity number"])

#             # input_df_dic['Activity'][0] = df_ref.iloc[i, df_ref.columns.get_loc('Activity')]
#             # input_df_dic['Sector'][0] = df_ref.iloc[i, df_ref.columns.get_loc('Sector')]
#             # input_df_dic['Activity number'][0] = df_ref.iloc[i, df_ref.columns.get_loc('Activity number')]

#             break

# # def adding():