# import pandas as pd
# import random
# from django.conf import settings
# import json
# from rest_framework import viewsets
# from rest_framework.response import Response
# from django.http import HttpResponse
# from esg_app.app_models.mapping_activity import Masked_data
# from esg_app.app_models.refrence_data import Refrenced_data
# from esg_app.app_models.data_table import Data_table

# DB = settings.MAPPING_FILE

# match = False

# input_df_dic = {
#             "invoice_supplier_name" : [],
#             "wns_normalized_vendor_name" : [],
#             "gl_account" : [],
#             "gl_account_mask_alphanumeric" : [],
#             "gl_account_mask_numeric" : [],
#             "material_description" : [],
#             "material_description_translated" : [],
#             "material_group_description" : [],
#             "gl_account_description" : [],
#             "concatenate_translated" : [],
#             "concatenate" : [],
#             "invoice_supplier_number" : [],
#             "invoice_supplier_no_mask_alphanumeric" : [],
#             "invoice_currency" : [],
#             "currency" : [],
#             "spend_amount" : [],
#             "spend_amt" : [],
#             "invoice_supplier_country" : [],
#             "country" : [],
#             "activity" : [],
#             "sector" : [],
#             "activity_number" : []
#         }

# # from django_pandas.io import read_frame
# # def mapping2(request):
# #     df_input = pd.DataFrame(list(Refrenced_data.objects.all().values()))
# #     print(df_input.head())
# #     return HttpResponse("e")
    



# def mapping():
#     global match, input_df_dic
#     df_input = pd.DataFrame(list(Masked_data.objects.all().values()))
#     # print(df_input.head())

#     num1 = random.randint(0, len(df_input)-1)
#     print(num1,'ooo')

#     # df_input_row =  df_input.iloc[[num1]]
#     # print(df_input_row)

        
#     s = ""
#     if pd.isnull(df_input.iloc[num1, df_input.columns.get_loc('material_description')]):
#         pass
#     else:
#         s = s + str(df_input.loc[num1, 'material_description']) + ' '

#     if pd.isnull(df_input.iloc[num1, df_input.columns.get_loc('material_group_description')]):
#         pass
#     else:
#         s = s + str(df_input.loc[num1, 'material_group_description']) + ' '

#     if pd.isnull(df_input.iloc[num1, df_input.columns.get_loc('gl_account_description')]):
#         pass
#     else:
#         s = s + str(df_input.loc[num1, 'gl_account_description'])

    

#     input_df_dic['invoice_supplier_name'].append(df_input.loc[num1, "invoice_supplier_name"])
#     input_df_dic['wns_normalized_vendor_name'].append(df_input.loc[num1, "wns_normalized_vendor_name"])
#     input_df_dic['gl_account'].append(df_input.loc[num1, "gl_account"])
#     input_df_dic['gl_account_mask_alphanumeric'].append(df_input.loc[num1, "gl_account_mask_alphanumeric"])
#     input_df_dic['gl_account_mask_numeric'].append(df_input.loc[num1, "gl_account_mask_numeric"])
#     input_df_dic['material_description'].append(df_input.loc[num1, "material_description"])
#     input_df_dic['material_description_translated'].append("")
#     input_df_dic['material_group_description'].append(df_input.loc[num1, "material_group_description"])
#     input_df_dic['gl_account_description'].append(df_input.loc[num1, "gl_account_description"])
#     input_df_dic['concatenate_translated'].append("")
#     input_df_dic['concatenate'].append(df_input.loc[num1, "concatenate"])
#     input_df_dic['invoice_supplier_number'].append(df_input.loc[num1, "invoice_supplier_number"])
#     input_df_dic['invoice_supplier_no_mask_alphanumeric'].append(df_input.loc[num1, "invoice_supplier_no_mask_alphanumeric"])
#     input_df_dic['invoice_currency'].append(df_input.loc[num1, "invoice_currency"])
#     input_df_dic['currency'].append(df_input.loc[num1, "currency"])
#     input_df_dic['spend_amount'].append(df_input.loc[num1, "spend_amount"])
#     input_df_dic['spend_amt'].append(df_input.loc[num1, "spend_amt"])
#     input_df_dic['invoice_supplier_country'].append(df_input.loc[num1, "invoice_supplier_country"])
#     input_df_dic['country'].append(df_input.loc[num1, "country"])

#     # df_ref = pd.read_excel(DB+'/reference_table.xlsx')
#     df_ref = pd.DataFrame(list(Refrenced_data.objects.all().values()))

#     # match = False

#     for i in range(len(df_ref)):

#         s_ref = ""
#         if pd.isnull(df_ref.iloc[i, df_ref.columns.get_loc('material_description')]):
#             pass
#         else:
#             s_ref = s_ref + str(df_ref.loc[i, 'material_description']) + ' '

#         if pd.isnull(df_ref.iloc[i, df_ref.columns.get_loc('material_group_description')]):
#             pass
#         else:
#             s_ref = s_ref + str(df_ref.loc[i, 'material_group_description']) + ' '

#         if pd.isnull(df_ref.iloc[i, df_ref.columns.get_loc('gl_account_description')]):
#             pass
#         else:
#             s_ref = s_ref + str(df_ref.loc[i, 'gl_account_description'])

#         if s.lower().lstrip().rstrip() == s_ref.lower().lstrip().rstrip():
#             match = True
#             print("match::")

#             print(df_ref.loc[i, "activity"])

#             input_df_dic['activity'].append(df_ref.loc[i, "activity"])
#             input_df_dic['sector'].append(df_ref.loc[i, "sector"])
#             input_df_dic['activity_number'].append(df_ref.loc[i, "activity_number"])

#             # input_df_dic['activity'][0] = df_ref.iloc[i, df_ref.columns.get_loc('activity')]
#             # input_df_dic['Sector'][0] = df_ref.iloc[i, df_ref.columns.get_loc('Sector')]
#             # input_df_dic['activity_number'][0] = df_ref.iloc[i, df_ref.columns.get_loc('activity_number')]

#             break
    



# class mappingActivity(viewsets.ViewSet):
#     def ACMapping(self, request):
#         mapping()     
#         if match:
#             print('matched')
            
#             df_data_table = pd.read_excel(DB+'/data_table.xlsx',index_col=0)
#             input_df_dic_dataframe =  pd.DataFrame(input_df_dic)
#             new_data_table_df = pd.concat([df_data_table, input_df_dic_dataframe], ignore_index=True)
#             new_data_table_df.to_excel(DB+'/data_table.xlsx')
#             print(input_df_dic)
#             response = Response()
#             response.data = {
#                                 "activity_mapping": "match",
#                                 "data": input_df_dic
#                             }
#             return response
        
#         else:
#             print('Not matched')
#             input_df_dic["activity"].append("Not Found")
#             input_df_dic["sector"].append("Not Found")
#             input_df_dic["activity_number"].append("Not Found")

            
#             df_data_table = pd.read_excel(DB+'/data_table.xlsx',index_col=0)
#             input_df_dic_dataframe =  pd.DataFrame(input_df_dic)
#             new_data_table_df = pd.concat([df_data_table, input_df_dic_dataframe], ignore_index=True)
#             new_data_table_df.to_excel(DB+'/data_table.xlsx')
#             print(input_df_dic)
#             response = Response()
#             response.data = {
#                                 "activity_mapping": "No match",
#                                 "data": input_df_dic
#                             }
#             return response

