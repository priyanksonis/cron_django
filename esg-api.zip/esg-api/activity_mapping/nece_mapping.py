# from django.db import connection
# from django.conf import settings
# import json
# import pandas as pd
# from django.http import HttpResponse

# DB = settings.MAPPING_FILE

# df_input = pd.read_excel(DB+'/kellogg_samples.xlsx')
# # print(df_input.dtypes)


# def Insert_data(request):
#     try:
#         with connection.cursor() as cursor:
#             for _, row in df_input.iterrows():
#                 print(row,"------------->")
#                 insert_query = '''
#             INSERT INTO esg_app_masked_data (invoice_supplier_name, wns_normalized_vendor_name,gl_account,gl_account_mask_alphanumeric,
#             gl_account_mask_numeric,material_description,material_group_description,gl_account_description,concatenate,
#             invoice_supplier_number,invoice_supplier_no_mask_alphanumeric,invoice_supplier_no_mask_numeric,invoice_currency,
#             currency,spend_amount,spend_amt,invoice_supplier_country,country,wns_group,wns_family,wns_category,wns_commodity,
#             nace_activity,sustainability_score)
#             VALUES (%s, %s, %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);
#             '''
                
#                 values = tuple(row)
#                 # print(values,"------------->")
#                 cursor.execute(insert_query, values)
#                 connection.commit()
#         return HttpResponse('DATA Executed')
#     except Exception as e:
#         return HttpResponse(e)

# # df_ref = pd.read_excel(DB+'/reference_table.xlsx')
# # print(df_ref.dtypes)
# """
# def Insert_ref_data(request):
#     try:
#         with connection.cursor() as cursor:
#             for _, row in df_ref.iterrows():
#                 insert_query = '''
#             INSERT INTO public.esg_app_refrenced_data(invoice_supplier_name,wns_normalized_vendor_name,gl_account,gl_account_mask_alphanumeric,
#             gl_account_mask_numeric,material_description_translated,material_description,material_group_description,
#             gl_account_description,concatenate_translated,concatenate,invoice_supplier_number,invoice_supplier_no_mask_alphanumeric,
#             invoice_currency,currency,spend_amount,spend_amt,invoice_supplier_country,country,activity,sector,activity_number)
#             VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);
#             '''

                
                
#                 values = tuple(row)
#                 cursor.execute(insert_query, values)
#                 connection.commit()
#         return HttpResponse('DATA Executed')
#     except Exception as e:
#         print('HI Suraj')
#         return HttpResponse(e)
# """