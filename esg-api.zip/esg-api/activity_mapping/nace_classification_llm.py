# import os
# import openai
# from pathlib import Path
# from dotenv import load_dotenv
# import pandas as pd
# from django.conf import settings

# DB = settings.MAPPING_FILE

# # dotenv_path = Path('azure_key.env')
# # load_dotenv(dotenv_path=dotenv_path)

# # openai.api_type = "azure"
# # openai.api_version = os.getenv("api_version") 
# # openai.api_base = os.getenv("api_base")  # Your Azure OpenAI resource's endpoint value.
# # openai.api_key = os.getenv("api_key")

# def get_sentiment(input_prompt):
#     response = openai.Completion.create(
#         engine="davinci003",
#         prompt=input_prompt,
#         temperature=0.1,
#         max_tokens=400,
#         top_p=1,
#         frequency_penalty=0,
#         presence_penalty=0,
#         stop=None
#     )
#     sentiment = response.choices[0].text.strip()
#     return sentiment

# def chatGPT_class(text, list_classes):
#     prompt = f"""
#     Classify the text into into one of the following classes,
#     Write the in details cause for choosing that following classes

#     {', '.join(list_classes)}

#     text: {text} 
#     label:
#     """
#     response_con = get_sentiment(prompt)
#     return response_con
    


# df = pd.read_excel(DB+'/NACE_processed.xlsx')
# df['Description'] = df['Description'].str.lower()

# categories = ['AGRICULTURE, FORESTRY AND FISHING','MINING AND QUARRYING','MANUFACTURING','ELECTRICITY, GAS, STEAM AND AIR CONDITIONING SUPPLY',
#               'WATER SUPPLY; SEWERAGE, WASTE MANAGEMENT AND REMEDIATION ACTIVITIES','CONSTRUCTION','TRANSPORTATION AND STORAGE',
#               'WHOLESALE AND RETAIL TRADE; REPAIR OF MOTOR VEHICLES AND MOTORCYCLES','ACCOMMODATION AND FOOD SERVICE ACTIVITIES',
#               'INFORMATION AND COMMUNICATION','FINANCIAL AND INSURANCE ACTIVITIES','REAL ESTATE ACTIVITIES','PROFESSIONAL, SCIENTIFIC AND TECHNICAL ACTIVITIES',
#               'ADMINISTRATIVE AND SUPPORT SERVICE ACTIVITIES','PUBLIC ADMINISTRATION AND DEFENCE; COMPULSORY SOCIAL SECURITY','EDUCATION',
#               'HUMAN HEALTH AND SOCIAL WORK ACTIVITIES','ARTS, ENTERTAINMENT AND RECREATION','OTHER SERVICE ACTIVITIES',
#               'ACTIVITIES OF HOUSEHOLDS AS EMPLOYERS; UNDIFFERENTIATED GOODS- AND SERVICES-PRODUCING ACTIVITIES OF HOUSEHOLDS FOR OWN USE',
#               'ACTIVITIES OF EXTRATERRITORIAL ORGANISATIONS AND BODIES']


# text = "Water cones TempHelp-NonProductn Cafeteria & Dinning"
# chatGPT_class(text, categories)

# def level_classification(text):
  
#   #call chatGPT ex. 'AGRICULTURE, FORESTRY AND FISHING' r1
  
#   r1 = chatGPT_class(text.lower(), categories).lower()
# #   print(r1+"************")
#   lev1 = r1.split('\n\n')[0]
#   cause = r1.split('\n\n')[1][7:]
#   print(lev1 +"----level1----")

  
#   level1 = df[['Description']].apply(lambda x: x.str.contains(lev1,regex=True)).any(axis=1)
# #   level1 = df[df['Description'] == lev1]
#   rows = df[df['Parent'].str.contains(df[level1].iloc[0]['Code'], na=False)]
#   level2_lst = rows['Description'].to_list()
#   print(df[level1].iloc[0]['Code'])
  
    
#   #call chatGPT  ex. "Forestry and logging" r2
#   r2 = chatGPT_class(text.lower(), level2_lst).lower()
#   print(r2,"---")
#   lev2 = r2.split('\n\n')[0]
#   cause2 = r2.split('\n\n')[1][7:]
#   print(lev2,"----level2----")
# #   print(cause2+"----cause----")
#   level2 = df[df['Description'] == lev2]
#   lst3 = df[df['Parent'] == level2.iloc[0]['Code']]
#   level3_lst = lst3['Description'].to_list()

  

#   #call chatGPT  ex. 'Aquaculture' r3
#   r3 = chatGPT_class(text.lower(), level3_lst).lower()
#   lev3 = r3.split('\n\n')[0]
#   cause3 = r3.split('\n\n')[1][7:]
#   print(lev3+"----Level3----")
  
#   level3 = df[df['Description'] == lev3]
#   print(level3)

#   lst4 = df[df['Parent'] == level3.iloc[0]['Code']]
#   print(level3.iloc[0]['Code'],"-->Code")
#   level4_lst = lst4['Description'].to_list()
#   print(level4_lst, "LIST 4")
    
#   #call chatGPT  ex. 'Freshwater aquaculture' r4
#   r4 = chatGPT_class(text.lower(), level4_lst).lower()
#   lev4 = r4.split('\n\n')[0]
#   cause4 = r4.split('\n\n')[1][7:]
#   print(lev4+"----Level4----")

#   #print(r1, r2, r3, r4, sep='\n')
#   #return level2_lst, level3_lst, level4_lst
# #   return lev1,lev2,lev3,lev4
#   return lev1,cause,lev2,cause2,lev3,cause3,lev4,cause4

# # input_string = "Water cones TempHelp-NonProductn Cafeteria & Dinning"
# # input_string = "Sweets TempHelp-NonProductn Company Meetings"
# # print(level_classification(input_string))