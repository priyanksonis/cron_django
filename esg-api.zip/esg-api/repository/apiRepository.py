from rest_framework import viewsets
from rest_framework.response import Response
from api_config import avarni_api
import requests

from django.http import HttpResponse

from api_config import avarni_api

access_token1 = None


class ApiAvarni(viewsets.ViewSet):

    def basic_token(self,request):
        global access_token1
        
        try:
            api_response = requests.post(avarni_api.token_endpoint, proxies=avarni_api.proxy, headers=avarni_api.basic_headers, verify=False)
            response_json = api_response.json()
            access_token1 = response_json["data"]["access_token"]
            print(type(access_token1))
            response = Response()
            response.data = {"token": response_json["data"]}
            return response
        except Exception as e:
            print(e)


    def api_avarni(self,request):
        global access_token1
        try:
            headers1 = {
                    "Authorization": f"Bearer {access_token1}",
                    "Content-Type": "application/json"
                    }
        
            api_response = requests.post(avarni_api.api_url, proxies=avarni_api.proxy, headers=headers1, data=avarni_api.json_body_str, verify=False)
            
            if api_response.status_code == 200:
                response_json = api_response.json()
                return Response(response_json)
            
            elif api_response.status_code  == 400:
                response = Response()
                response.data = {
                                    "code": 400,
                                    "message": "transactionId is required."
                                }
                return response
        
            elif api_response.status_code  == 403:
                response = Response()
                response.data = {
                                    "message": "The API Key was invalid or empty"
                                }
                return response
            
            elif api_response.status_code  == 500:
                response = Response()
                response.data = {
                                    "code": "internal-server-error",
                                    "message": "There was an internal server error. Contact support@avarni.co for help."
                                }
                return response
        except Exception as e:
            return HttpResponse(e)
