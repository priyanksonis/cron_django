from esg_app.app_models.company import EsgCompanies
from esg_app.app_models.client_transactions import EsgClientTransaction
from esg_app.app_models.emission_transaction import EsgEmissionTransaction
from esg_app.app_models.scope import EsgStaticScope
from esg_app.app_models.categories import EsgStaticCategories
from rest_framework.response import Response
from rest_framework import status
from django.core import serializers
from rest_framework import viewsets
from django.db.models import Q
from serializers.scope_serializer import ScopeCatSerializer,ScopeSerializer,EsgStaticScopeSerializer, ScopeCategorySerializer1,ScopeCategorySerializer2,ScopeCategorySerializer3
from django.conf import settings
import json
from django.db import connection
from django.db.models.query import QuerySet
import json
from uuid import UUID
from decimal import Decimal
from datetime import datetime,date
from django.http import JsonResponse

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            return str(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, date):
            return obj.isoformat()
        elif isinstance(obj, Decimal):
            return str(obj)
        return super().default(obj)

def filter_data_by_date_range(data, start_date, end_date):
    filtered_data = []
    for row in data:
        if start_date <= str(row[2]) <= end_date:
            filtered_data.append(row)
    return filtered_data


DB = settings.DB_FILE
JSON_API = settings.JSON_ACTIVE



class ScopeRepo(viewsets.ViewSet):

    if JSON_API == True:
        def get_scope_list(self,request):
            with open(DB+"/scope_list.json", mode = "r") as jFile:
                data = json.load(jFile)
            return JsonResponse(list(data), safe=False)
                # scope_data = [{"scope_list":{"scope":data}}]
            # result = ScopeSerializer(scope_data, many=True).data
            # return Response(result)
        
        def get_scope_category(self,request,pk,*args, **kwargs):
            with open(DB+"/scope_category.json", mode = "r") as jFile:
                data = json.load(jFile)
                print(type(data))
            
            # result = ScopeCatSerializer(data).data
            return JsonResponse(list(data), safe=False)
        
    else:
        
        def get_scope_list(self,request):
            scope = EsgStaticScope.objects.all()
            serializer = EsgStaticScopeSerializer(scope, many = True)
            return Response(serializer.data)
        
        def get_scope(self,request,pk):
            with connection.cursor() as cursor:
                print("test2")
                try:
                    cursor.execute(f"select * from SP_scope('{pk}')")
                    data = cursor.fetchall()
                    columns = [col[0] for col in cursor.description]
                    queryset_data = [dict(zip(columns, row)) for row in data]

                    serialized_data = json.dumps(queryset_data, cls=CustomJSONEncoder)
                    serialized_data = json.loads(serialized_data)
                    print(serialized_data)
                except Exception as e:
                    print(e)
                response = JsonResponse(serialized_data, safe=False)
                return response
                
        def get_scope_category(self,request,pk,*args, **kwargs):
            start_date = request.data['start_date']
            end_date = request.data['end_date']

            with connection.cursor() as cursor:
                print('Suraj123')
                try:
                    cursor.execute(f"select * from sp_scope_category1('{pk}')")
                    data = cursor.fetchall()
                    filtered_result = filter_data_by_date_range(data, start_date, end_date)
                    queryset_data = []
                    for row in filtered_result:
                        if row[1] == 1:
                            data = {
                                    "scope_1": {
                                        "category_details": [
                                            {
                                                "category_name": row[0],
                                                "emission_total_value": 5.025005,
                                                "emission_current_value": 4.9652185
                                            }
                                        ],
                                        "emission_total_value": 1.1730742,
                                        "emission_past_value": 6.846853,
                                        "emission_current_value": 7.4577446
                                        }
                                    }
                            queryset_data.append(data)
                        elif row[1] == 2:
                            data = {
                                    "scope_2": {
                                        "category_details": [
                                            {
                                                "category_name": row[0],
                                                "emission_total_value": 5.025005,
                                                "emission_current_value": 4.9652185
                                            }
                                        ],
                                        "emission_total_value": 1.1730742,
                                        "emission_past_value": 6.846853,
                                        "emission_current_value": 7.4577446
                                        }
                                    }
                            queryset_data.append(data)
                        elif row[1] == 3:
                            data = {
                                    "scope_3": {
                                        "category_details": [
                                            {
                                                "category_name": row[0],
                                                "emission_total_value": 5.025005,
                                                "emission_current_value": 4.9652185
                                            }
                                        ],
                                        "emission_total_value": 1.1730742,
                                        "emission_past_value": 6.846853,
                                        "emission_current_value": 7.4577446
                                        }
                                    }
                            queryset_data.append(data)
                    serialized_data = json.dumps(queryset_data, cls=CustomJSONEncoder)
                    serialized_data = json.loads(serialized_data)
                except Exception as e:
                    print(e)
                response = JsonResponse(serialized_data, safe=False)
                return response
        