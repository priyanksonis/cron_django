import jwt, datetime

def create_access_token(id):
    return jwt.encode({
        'id': str(id),
        'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
        'iat' : datetime.datetime.utcnow()
    }, 'refresh_secret',algorithm = 'HS256')


def create_refresh_token(id):
    return jwt.encode({
        'id': str(id),
        'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=600),
        'iat' : datetime.datetime.utcnow()
    }, 'refresh_secret',algorithm = 'HS256')