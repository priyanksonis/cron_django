from rest_framework import generics
from esg_app.app_models.emission_transaction import EsgEmissionTransaction
from esg_app.app_models.company import EsgCompanies
from esg_app.app_models.units import EsgStaticUnits
from esg_app.app_models.categories import EsgStaticCategories
from esg_app.app_models.vendor import EsgVendors
from esg_app.app_models.contries import EsgStaticContries
from esg_app.app_models.client_transactions import EsgClientTransaction
from rest_framework.response import Response
from rest_framework import viewsets
from serializers.emission_serializer import ScopeAnalysisSerializer,EmissionDetailsSerializer,VendorCalculationSerializer,VendorCalculationSerializer1
from django.db.models import Q
from django.forms.models import model_to_dict
from uuid import UUID
import json
from decimal import Decimal
from datetime import datetime,date
from django.http import JsonResponse
from django.db import connection

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            return str(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, date):
            return obj.isoformat()
        elif isinstance(obj, Decimal):
            return str(obj)
        return super().default(obj)

from django.conf import settings
import json

DB = settings.DB_FILE
JSON_API = settings.JSON_ACTIVE

def filter_data_by_date_range(data, start_date, end_date):
    filtered_data = []
    for row in data:
        if start_date <= str(row[1]) <= end_date:
            filtered_data.append(row)
    return filtered_data

class EmissionRepo(viewsets.ViewSet):

    if JSON_API == True:
        def get_emission_details(self,request,pk):
            with open(DB+"/emission_details.json", mode = "r") as jFile:
                data = json.load(jFile)
                print(data)

            return JsonResponse(list(data), safe=False)
            # result = EmissionDetailsSerializer(data).data
            # return Response(result)

        def get_emission_vendor_calculation(self,request,pk):
            with open(DB+"/emission_calculation.json", mode = "r") as jFile:
                data = json.load(jFile)
                print(data)
            return JsonResponse(list(data), safe=False)
        
        def get_emission_analytics(self,request,pk):
            with open(DB+"/emission_analysis.json", mode = "r") as jFile:
                data = json.load(jFile)
                print(type(data))

            # result = ScopeAnalysisSerializer(data).data
            return JsonResponse(list(data), safe=False)

    else:
        def get_emission_details(self,request,pk):
            with connection.cursor() as cursor:
                print("test2")
                try:
                    cursor.execute(f"select * from sp_emissiondetails('{pk}')")
                    data = cursor.fetchall()
                    columns = [col[0] for col in cursor.description]
                    queryset_data = [dict(zip(columns, row)) for row in data]

                    serialized_data = json.dumps(queryset_data, cls=CustomJSONEncoder)
                    serialized_data = json.loads(serialized_data)
                    print(serialized_data)
                except Exception as e:
                    print(e)
                response = JsonResponse(serialized_data, safe=False)
                return response
            
        
        
        def get_emission_vendor_calculation(self,request,pk):
            start_date = request.data['start_date']
            end_date = request.data['end_date']
            with connection.cursor() as cursor:
                print('Suraj123')
                try:
                    cursor.execute(f"select * from sp_emission_calculation('{pk}')")
                    data = cursor.fetchall()

                    # columns = [col[0] for col in cursor.description]
                    # queryset_data = [dict(zip(columns, row)) for row in data]
                    filtered_result = filter_data_by_date_range(data, start_date, end_date)

                    queryset_data = []
                    for row in filtered_result:
                        data = {
                                "vendor_country": row[0],
                                "vendor_date": row[1],
                                "vendor_id": row[2],
                                "vendor_name": row[3],
                                "vendor_details": {
                                    "category_details": [
                                        {
                                            "category_name": row[4],
                                            "emission_total_value": 5.025005,
                                            "emission_current_value": 4.9652185
                                        }
                                    ],
                                    "emission_total_value": 5.962134,
                                    "emission_past_value": 6.0274563,
                                    "emission_current_value": 1.4658129
                                },
                                "vendor_domain": row[5]
                            }
                        queryset_data.append(data)
                    serialized_data = json.dumps(queryset_data, cls=CustomJSONEncoder)
                    serialized_data = json.loads(serialized_data)
                    print(serialized_data)
                except Exception as e:
                    print(e)
                response = JsonResponse(serialized_data, safe=False)
                return response

