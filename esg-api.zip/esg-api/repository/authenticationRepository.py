from rest_framework.response import Response
from django.shortcuts import render, redirect
from rest_framework.views import APIView
from django.contrib.auth.models import User
from serializers.serializers import UserSerializer
from rest_framework.exceptions import AuthenticationFailed
from repository.jwtTokenRepository import create_access_token,create_refresh_token
import jwt, datetime
import random
from . import emailRepository
from django.core.mail import EmailMessage
from esg_app.app_models.validate_otp import OTP_model
from esg_app.app_models.esg_user import EsgUsers
from rest_framework import viewsets

class UserAuthRepo(viewsets.ViewSet):
    
    def create_user(self, request):
        serializer = UserSerializer(data=request.data)
        # roleserial = RoleSerializer(data=request.data)
        email = request.data['email']
        username = request.data['username']
        uname = request.data['first_name']
        role = request.data['role']
        serializer.is_valid(raise_exception=True)

        valid = User.objects.filter(email=email).first()
        if valid:
            raise AuthenticationFailed('Email already registered!')
        serializer.save()
        user = User.objects.get(email = email)
        
        otp = str(random.randint(1000,9999))
        otp_model = OTP_model(otp = otp,username=username)
        role_model = EsgUsers(user = user, user_role = role)
        
        otp_model.save()
        role_model.save()
        emailRepository.send_otp(uname,email,otp)
        request.session['email'] = otp
        request.session['username'] = username

        # return redirect('otp')
        print(serializer.data.get('email'))
        return Response(serializer.data)


    def login_users(self, request):
        username = request.data['username']
        password = request.data['password']
        user = User.objects.filter(username=username).first()

        role = EsgUsers.objects.get(user_id=user.id)
        user_valid = OTP_model.objects.get(username=username)
        print('1.',user_valid.isValid, '2.',user.id)

        # if user_valid.isValid != 1:
        #     raise AuthenticationFailed('OTP not validated!')

        if user is None:
            raise AuthenticationFailed('User not found!')

        if not user.check_password(password):
            raise AuthenticationFailed('Incorrect password')
        
        access_token = create_access_token(user_valid.user_id)
        refresh_token = create_refresh_token(user_valid.user_id)

        response = Response()
        response.set_cookie(key='refresh_token', value=refresh_token, httponly=True)

        response.data = {
            'username': username,
            'access_token': access_token,
            'role' : role.user_role
        }
        return response

    def logout_users(self, request):
        response = Response()
        response.delete_cookie('jwt')
        response.data  = {
            'message': 'success'
        }
        return response

class UserRepo(APIView):
    def get(self, request):
        token = request.COOKIES.get('refresh_token')

        if not token:
            raise AuthenticationFailed('Unauthenticated')
        
        try:
            payload = jwt.decode(token,'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Token Expired')

        user = User.objects.filter(id = payload['id']).first()
        serializer = UserSerializer(user)

        return Response(serializer.data)

