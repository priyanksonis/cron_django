from rest_framework.response import Response
from rest_framework import viewsets
from esg_app.app_models.news_articles import NewsArticles
from serializers.articles_serializer import ArticlesSerializer

from newsarticles import get_news
#esg-api/newsArtcles/get_news.py


#fetch new and put in db periodically
def my_scheduled_job():
  print("this is a test cron job")

  # delete old news from table
  NewsArticles.objects.all().delete()

  # insert fresh news in table
  all_company_news = get_news.get_all_news()

  for company in all_company_news:
      for k, v in company.items():
          member_news = NewsArticles(company_name=v['company_name'], news_title=v['title'], url=v['url'],
                                     publisher=v['publisher'], date=v['date'], e='w', s='r', g='w')
          member_news.save()


class NewsArticleRepo(viewsets.ViewSet):
    def get_news_letter(self,request):

        query = NewsArticles.objects.all()
        serializer = ArticlesSerializer(query, many=True)
        return Response(serializer.data)