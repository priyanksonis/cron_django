from rest_framework.response import Response
from esg_app.app_models.vendor import EsgVendors
from esg_app.app_models.company import EsgCompanies
from esg_app.app_models.location import EsgLocations
from esg_app.app_models.contries import EsgStaticContries
from esg_app.app_models.client_transactions import EsgClientTransaction
from esg_app.app_models.emission_transaction import EsgEmissionTransaction
from rest_framework import viewsets
from esg_app.app_models.categories import EsgStaticCategories
from serializers.vendor_serializer import EsgVendorSerializer,VendorSerializer
from django.core import serializers
from django.conf import settings
import json
from uuid import UUID
from datetime import datetime,date
from django.http import JsonResponse
from django.db import connection

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            return str(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, date):
            return obj.isoformat()
        return super().default(obj)
    
DB = settings.DB_FILE
JSON_API = settings.JSON_ACTIVE

class VendorRepo(viewsets.ViewSet):
    if JSON_API == True:
        def get_vendor(self, request, pk):
            with open(DB+"/vendor_api.json", mode = "r") as jFile:
                    data = json.load(jFile)
                    print(type(data))
            return JsonResponse(list(data), safe=False)

        def get_vendor_details(self, request, pk):
            with open(DB+"/vendor_details.json", mode = "r") as jFile:
                    data = json.load(jFile)
                    print(type(data))
                    
            return JsonResponse(list(data), safe=False)

    else:
        def get_vendor(self, request,pk):
             with connection.cursor() as cursor:
                print('Suraj123')
                try:
                    cursor.execute(f"select * from sp_vendor('{pk}')")
                    data = cursor.fetchall()

                    # columns = [col[0] for col in cursor.description]
                    # queryset_data = [dict(zip(columns, row)) for row in data]

                    queryset_data = []
                    for row in data:
                        data = {
                                "vendor_country": row[0],
                                "vendor_date": row[1],
                                "vendor_id": row[2],
                                "vendor_name": row[3],
                                "vendor_details": {
                                    "category_details": [
                                        {
                                            "category_name": row[4],
                                            "emission_total_value": 5.025005,
                                            "emission_current_value": 4.9652185
                                        }
                                    ],
                                    "emission_total_value": 5.962134,
                                    "emission_past_value": 6.0274563,
                                    "emission_current_value": 1.4658129
                                },
                                "vendor_domain": row[5]
                            }
                        queryset_data.append(data)
                    print(queryset_data)
                    serialized_data = json.dumps(queryset_data, cls=CustomJSONEncoder)
                    serialized_data = json.loads(serialized_data)
                    print(serialized_data)
                except Exception as e:
                    print(e)
                response = JsonResponse(serialized_data, safe=False)
                return response
             

        def get_vendor_details(self, request, pk, *args, **kwargs):
            with connection.cursor() as cursor:
                print('Suraj123')
                try:
                    cursor.execute(f"select * from sp_vendor_companydetails('{pk}')")
                    data = cursor.fetchall()

                    # columns = [col[0] for col in cursor.description]
                    # queryset_data = [dict(zip(columns, row)) for row in data]

                    queryset_data = []
                    for row in data:
                        data = {
                                "vendor_country": row[0],
                                "vendor_date": row[1],
                                "vendor_id": row[2],
                                "vendor_name": row[3],
                                "vendor_details": {
                                    "category_details": [
                                        {
                                            "category_name": row[4],
                                            "emission_total_value": 5.025005,
                                            "emission_current_value": 4.9652185
                                        }
                                    ],
                                    "emission_total_value": 5.962134,
                                    "emission_past_value": 6.0274563,
                                    "emission_current_value": 1.4658129
                                },
                                "vendor_domain": row[5]
                            }
                        queryset_data.append(data)
                    print(queryset_data)
                    serialized_data = json.dumps(queryset_data, cls=CustomJSONEncoder)
                    serialized_data = json.loads(serialized_data)
                    print(serialized_data)
                except Exception as e:
                    print(e)
                response = JsonResponse(serialized_data, safe=False)
                return response