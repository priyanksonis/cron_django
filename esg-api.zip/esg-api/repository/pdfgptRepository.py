from django.http import JsonResponse
from rest_framework.response import Response
from esg_app.app_models.pdfGPT import ChatDocModel
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.http import HttpResponse
import openai
from pdfGPT import pdfGPT
from rest_framework import viewsets


def upload(request):
    print('going inside')
    if request.method == "POST":
        uploaded_file = request.FILES.get('uploaded_file')
        text_input = request.POST.get('text_input')
        
        if uploaded_file and text_input:
            file_name = uploaded_file.name
            print(file_name, text_input)
            ChatDocModel.objects.create(uploaded_file=uploaded_file)
            return render(request,'sample.html')
    return render(request,'sample.html')

class PdfGPTRepository(viewsets.ViewSet):
    def upload_file(self, request):
        print(':Hello pk')
        text = request.POST.get('text')
        uploaded_file = request.FILES.get('uploaded_file')
        if uploaded_file:
            try:
                file_name = uploaded_file.name
                chat_doc = ChatDocModel.objects.create(uploaded_file=uploaded_file)

                answer = pdfGPT.question_answer(url="", file=chat_doc.uploaded_file.path, question=text, openAI_key=openai.api_key)

                response = Response()
                response.data = {
                    "Question": text,
                    "Response": answer,
                    "File Name": file_name
                    
                }
                return response
            except Exception as e:
                print(e, 'upload_file Error: upload_files')

    def upload_url(self, request):
        text = request.POST.get('text')
        upload_files = request.POST.get('upload_file')
        file_name = upload_files.split('/')
        if upload_files:
            try:
                answer = pdfGPT.question_answer(url=upload_files, file=None, question=text, openAI_key=openai.api_key)
                # answer = pdfGPT.question_answer(url='https://s3.wns.com/S3_5/Documents/ESG-Microsite/ESG/WNS-ESG-Report-FY-2022.pdf', file=None, question="What is the value of GHG emissions?", openAI_key=openai.api_key)
                response = Response()
                response.data = {
                    'Question': 'What is the value of GHG emissions?',
                    'Response': answer,
                    "File Name": file_name[-1]
                }
                return response
            except:
                return Response({
                                    'Error': "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:997)>"},
                                status=500)

    # else:
    #     return Response({'message': 'SSL Error'}, status=400)

