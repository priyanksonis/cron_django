from rest_framework.views import APIView
from rest_framework.response import Response
from esg_app.app_models.company import EsgCompanies
from esg_app.app_models.location import EsgLocations
from esg_app.app_models.contries import EsgStaticContries
from serializers.company_serializer import CompanySerializer
from rest_framework.decorators import action
from rest_framework import viewsets
from django.conf import settings
import json
from django.db import connection
from uuid import UUID
from datetime import datetime
from django.http import JsonResponse

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            return str(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

DB = settings.DB_FILE
JSON_API = settings.JSON_ACTIVE

class CompanyRepository(viewsets.ViewSet):
    if JSON_API == True:
        def get_company(self, request, pk,format=None):
            with open(DB+"/company_api.json", mode = "r") as jFile:
                data = json.load(jFile)
                print(type(data))
            return JsonResponse(list(data), safe=False)
    
    else:
        
        def get_company(self, request,pk):
            with connection.cursor() as cursor:
                try:
                    cursor.execute(f"select * from sp_company1('{pk}')")
                    data = cursor.fetchall()

                    columns = [col[0] for col in cursor.description]
                    queryset_data = [dict(zip(columns, row)) for row in data]
                    print(queryset_data)
                    serialized_data = json.dumps(queryset_data, cls=CustomJSONEncoder)
                    serialized_data = json.loads(serialized_data)
                    print(serialized_data)
                except Exception as e:
                    print(e)
                response = JsonResponse(serialized_data, safe=False)
                return response
