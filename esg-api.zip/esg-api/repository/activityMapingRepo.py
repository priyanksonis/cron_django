from rest_framework import viewsets
from rest_framework.response import Response
# from activity_mapping import sustainability_mapping, nace_classification_llm
import requests
import pandas as pd
# from esg_app.app_models.data_table import Data_table
from django.http import HttpResponse
from serializers.sustainability_serializer import SustainabilitySerializer

from esg_app.app_models.mapping_activity import Masked_data
'''
input_df_dic = {
            "invoice_supplier_name" : [],
            "wns_normalized_vendor_name" : [],
            "gl_account" : [],
            "gl_account_mask_alphanumeric" : [],
            "gl_account_mask_numeric" : [],
            "material_description" : [],
            "material_description_translated" : [],
            "material_group_description" : [],
            "gl_account_description" : [],
            "concatenate_translated" : [],
            "concatenate" : [],
            "invoice_supplier_number" : [],
            "invoice_supplier_no_mask_alphanumeric" : [],
            "invoice_currency" : [],
            "currency" : [],
            "spend_amount" : [],
            "spend_amt" : [],
            "invoice_supplier_country" : [],
            "country" : [],
            "activity" : [],
            "sector" : [],
            "activity_number" : []
        }

class mappingActivity(viewsets.ViewSet):
    def Mapping(self,request):
        sustainability_mapping.mapping()
        print('Suraj123')
        if sustainability_mapping.match:
            try:
                p = Data_table(invoice_supplier_name = sustainability_mapping.input_df_dic['invoice_supplier_name'][0],wns_normalized_vendor_name = sustainability_mapping.input_df_dic['wns_normalized_vendor_name'][0],gl_account = sustainability_mapping.input_df_dic["gl_account"][0],
                               gl_account_mask_alphanumeric = sustainability_mapping.input_df_dic["gl_account_mask_alphanumeric"][0],gl_account_mask_numeric = sustainability_mapping.input_df_dic["gl_account_mask_numeric"][0],material_description = sustainability_mapping.input_df_dic['material_description'][0],
                                 material_description_translated = sustainability_mapping.input_df_dic["material_description_translated"][0],material_group_description = sustainability_mapping.input_df_dic["material_group_description"][0],gl_account_description = sustainability_mapping.input_df_dic["gl_account_description"][0],
                                 concatenate_translated = sustainability_mapping.input_df_dic["concatenate_translated"][0],concatenate = sustainability_mapping.input_df_dic["concatenate"][0],invoice_supplier_number = sustainability_mapping.input_df_dic["invoice_supplier_number"][0],invoice_supplier_no_mask_alphanumeric = sustainability_mapping.input_df_dic["invoice_supplier_no_mask_alphanumeric"][0],
                                 invoice_currency = sustainability_mapping.input_df_dic["invoice_currency"][0],currency = sustainability_mapping.input_df_dic["currency"][0],spend_amount = sustainability_mapping.input_df_dic["spend_amount"][0],spend_amt = sustainability_mapping.input_df_dic["spend_amt"][0],
                                 invoice_supplier_country = sustainability_mapping.input_df_dic["invoice_supplier_country"][0],country = sustainability_mapping.input_df_dic["country"][0],activity = sustainability_mapping.input_df_dic["activity"][0],sector = sustainability_mapping.input_df_dic["sector"][0],activity_number = sustainability_mapping.input_df_dic["activity_number"][0])
                p.save()
                sustainability_mapping.input_df_dic = input_df_dic
                sustainability_mapping.match = False
                response = Response()
                response.data = {
                                    "activity_mapping": "match"
                                }
                
                return response
            except Exception as e:
                print(e)
        else:
            try:
                sustainability_mapping.input_df_dic["activity"].append("Not Found")
                sustainability_mapping.input_df_dic["sector"].append("Not Found")
                sustainability_mapping.input_df_dic["activity_number"].append("Not Found")

                p = Data_table(invoice_supplier_name = sustainability_mapping.input_df_dic['invoice_supplier_name'][0],wns_normalized_vendor_name = sustainability_mapping.input_df_dic['wns_normalized_vendor_name'][0],gl_account = sustainability_mapping.input_df_dic["gl_account"][0],
                               gl_account_mask_alphanumeric = sustainability_mapping.input_df_dic["gl_account_mask_alphanumeric"][0],gl_account_mask_numeric = sustainability_mapping.input_df_dic["gl_account_mask_numeric"][0],material_description = sustainability_mapping.input_df_dic['material_description'][0],
                                 material_description_translated = sustainability_mapping.input_df_dic["material_description_translated"][0],material_group_description = sustainability_mapping.input_df_dic["material_group_description"][0],gl_account_description = sustainability_mapping.input_df_dic["gl_account_description"][0],
                                 concatenate_translated = sustainability_mapping.input_df_dic["concatenate_translated"][0],concatenate = sustainability_mapping.input_df_dic["concatenate"][0],invoice_supplier_number = sustainability_mapping.input_df_dic["invoice_supplier_number"][0],invoice_supplier_no_mask_alphanumeric = sustainability_mapping.input_df_dic["invoice_supplier_no_mask_alphanumeric"][0],
                                 invoice_currency = sustainability_mapping.input_df_dic["invoice_currency"][0],currency = sustainability_mapping.input_df_dic["currency"][0],spend_amount = sustainability_mapping.input_df_dic["spend_amount"][0],spend_amt = sustainability_mapping.input_df_dic["spend_amt"][0],
                                 invoice_supplier_country = sustainability_mapping.input_df_dic["invoice_supplier_country"][0],country = sustainability_mapping.input_df_dic["country"][0],activity = sustainability_mapping.input_df_dic["activity"][0],sector = sustainability_mapping.input_df_dic["sector"][0],activity_number = sustainability_mapping.input_df_dic["activity_number"][0])
                p.save()
                sustainability_mapping.input_df_dic = input_df_dic
                sustainability_mapping.match = False
                response = Response()
                response.data = {
                                    "activity_mapping": "Not match"
                                }
                
                return response
            except Exception as e:
                print(e)



class levelClasification(viewsets.ViewSet):
    def classification(self,request):
        text = request.data['text']
        try:
            output = nace_classification_llm.level_classification(text)
            print(output)
            response = Response()
            response.data = {
                                "Level1": output[0],
                                "Cause1": output[1],
                                "Level2": output[2],
                                "Cause2": output[3],
                                "Level3": output[4],
                                "Cause3": output[5],
                                "Level4": output[6],
                                "Cause4": output[7],
                            }
            
            return response
        except Exception as e:
            print(e)
'''

class sustainabilityActivity(viewsets.ViewSet):
    def sustainability_add(self,request):
        invoice_supplier_name = request.data['invoice_supplier_name']
        wns_normalized_vendor_name = request.data['wns_normalized_vendor_name']
        gl_account = request.data['gl_account']
        gl_account_mask_alphanumeric = request.data['gl_account_mask_alphanumeric']
        gl_account_mask_numeric = request.data['gl_account_mask_numeric']
        material_description = request.data['material_description']
        material_group_description = request.data['material_group_description']
        gl_account_description = request.data['gl_account_description']
        concatenate = request.data['concatenate']
        invoice_supplier_number = request.data['invoice_supplier_number']
        invoice_supplier_no_mask_alphanumeric = request.data['invoice_supplier_no_mask_alphanumeric']
        invoice_supplier_no_mask_numeric = request.data['invoice_supplier_no_mask_numeric']
        invoice_currency = request.data['invoice_currency']
        currency = request.data['currency']
        spend_amount = request.data['spend_amount']
        spend_amt = request.data['spend_amt']
        invoice_supplier_country = request.data['country']
        country = request.data['country']
        wns_group = request.data['wns_group']
        wns_family = request.data['wns_family']
        wns_category = request.data['wns_category']
        wns_commodity = request.data['wns_commodity']
        nace_activity = request.data['nace_activity']
        sustainability_score = request.data['sustainability_score']

        data = Masked_data(invoice_supplier_name=invoice_supplier_name,wns_normalized_vendor_name=wns_normalized_vendor_name,gl_account=gl_account,
                             gl_account_mask_alphanumeric=gl_account_mask_alphanumeric,gl_account_mask_numeric=gl_account_mask_numeric,material_description=material_description,
                             material_group_description=material_group_description,gl_account_description=gl_account_description,invoice_supplier_number=invoice_supplier_number,
                             invoice_supplier_no_mask_alphanumeric=invoice_supplier_no_mask_alphanumeric,invoice_supplier_no_mask_numeric=invoice_supplier_no_mask_numeric,
                             invoice_currency=invoice_currency,currency=currency,spend_amount=spend_amount,spend_amt=spend_amt,invoice_supplier_country=invoice_supplier_country,
                             country=country,wns_group=wns_group,wns_family=wns_family,wns_category=wns_category,wns_commodity=wns_commodity,nace_activity=nace_activity,
                             sustainability_score=sustainability_score)

        data.save()

        response = Response()
        response.data = {
            'Msg': "Updated"
        }
        return response
        # result = Masked_data.objects.all()
        # serializer = SustainabilitySerializer(result, many = True)
        # return Response(serializer.data)
    
    def sustainability_view(self,request):
        result = Masked_data.objects.all()
        serializer = SustainabilitySerializer(result, many = True)
        return Response(serializer.data)
