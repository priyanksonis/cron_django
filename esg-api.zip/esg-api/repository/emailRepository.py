from rest_framework.exceptions import AuthenticationFailed
from rest_framework.views import APIView
from rest_framework.response import Response
from django.core.mail import send_mail, send_mass_mail
from django.conf import settings
from datetime import datetime
from esg_app.app_models.validate_otp import OTP_model
from django.contrib.auth.models import User




def send_otp(username, email, otp):
    print('--',username,': 1', email,': 2', otp,': 3')
    # now = datetime.now()
    # dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    # send_mail(f"Welcome Mail",
    #         f"Hello {username}, \n\n Your One-Time Password (OTP) is {otp}, as requested on {dt_string}.", 
    #         settings.EMAIL_HOST_USER, 
    #         [email],fail_silently=False)
    return None


class OTPRepo(APIView):
    def post(self, request):
        sess_otp = request.session['email']
        user_otp = request.data['otp']
        username = request.session['username']
        print(sess_otp,user_otp)
        if str(user_otp) == str(sess_otp):
            validity = OTP_model.objects.filter(username = username).update(isValid = True)
            print('1.',username,'2.',validity)
            response = Response()
            response.data = {
                'msg': 'OTP Validated'
            }
            return response
        else:
            raise AuthenticationFailed('Invalid OTP!')