from django.urls import path, include
from service import vendorService
from rest_framework import routers

router = routers.SimpleRouter()
# router.register('api/V1/company', companyService.CompanyRepository, basename='company')
# urlpatterns = router.urls


urlpatterns = [
    path('vendor/<str:pk>', vendorService.VendorRepo.as_view({'get': 'get_vendor'})),
    path('vendor/<str:pk>/details',vendorService.VendorRepo.as_view({'get': 'get_vendor_details'})),
    path('', include(router.urls)),
]