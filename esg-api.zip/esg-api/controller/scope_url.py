from django.urls import path, include
from service import scopeService
from rest_framework import routers
from repository import scopeRepository

router = routers.SimpleRouter()


urlpatterns = [
    path('scope', scopeService.ScopeRepo.as_view({'get': 'get_scope_list'})),
    path('scope/<str:pk>/category', scopeService.ScopeRepo.as_view({'post': 'get_scope_category'})),
    path('scope/<str:pk>', scopeService.ScopeRepo.as_view({'get': 'get_scope'})),
    path('', include(router.urls)),
]