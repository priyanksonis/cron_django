from django.urls import path, include
from service import activityMappingService
from rest_framework import routers
from activity_mapping import sustainability_mapping, nece_mapping
from repository import activityMapingRepo
from pdfGPT import pdfGPT
from repository import pdfgptRepository

router = routers.SimpleRouter()
# router.register('api/V1/company', companyService.CompanyRepository, basename='company')
# urlpatterns = router.urls


urlpatterns = [
    path('chat_doc/pdf_url', pdfgptRepository.PdfGPTRepository.as_view({'post':"upload_url"})),
    path('chat_doc/pdf_file', pdfgptRepository.PdfGPTRepository.as_view({'post':"upload_file"})),
    path('pdfgpt', pdfGPT.pdf_gpt),
    path('uplode', pdfgptRepository.upload),
    path('', include(router.urls)),
    ]