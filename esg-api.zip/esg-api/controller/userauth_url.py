from django.urls import path, include
from service import authService, emailService
from rest_framework import routers

router = routers.SimpleRouter()

urlpatterns = [
    path('register', authService.UserAuthRepo.as_view({'post': 'create_user'})),
    path('login', authService.UserAuthRepo.as_view({'post': 'login_users'})),
    path('user', authService.UserRepo.as_view()),
    path('logout', authService.UserAuthRepo.as_view({'post':'logout_users'})),
    path('', include(router.urls))
]