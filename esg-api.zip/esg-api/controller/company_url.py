from django.urls import path, include
from service import companyService
from rest_framework import routers

router = routers.SimpleRouter()
# router.register('api/V1/company', companyService.CompanyRepository, basename='company')
# urlpatterns = router.urls


urlpatterns = [
    path('company/<str:pk>', companyService.CompanyRepository.as_view({'get': 'get_company'})),
    path('', include(router.urls)),
]