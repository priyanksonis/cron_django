from django.urls import path, include
from service import emissionService
from rest_framework import routers

router = routers.SimpleRouter()
# router.register('api/V1/company', companyService.CompanyRepository, basename='company')
# urlpatterns = router.urls


urlpatterns = [
    path('emission/<str:pk>/details', emissionService.EmissionRepo.as_view({'get': 'get_emission_details'})),
    path('emission/<str:pk>/analytics', emissionService.EmissionRepo.as_view({'get': 'get_emission_analytics'})),
    path('emission/<str:pk>/vendor/calculation', emissionService.EmissionRepo.as_view({'post': 'get_emission_vendor_calculation'})),
    
    path('', include(router.urls)),
]