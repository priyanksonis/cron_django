from django.urls import path, include
from service import activityMappingService
from rest_framework import routers
from activity_mapping import sustainability_mapping, nece_mapping
from repository import activityMapingRepo

router = routers.SimpleRouter()
# router.register('api/V1/company', companyService.CompanyRepository, basename='company')
# urlpatterns = router.urls


urlpatterns = [
    # path('activity_mapping', activityMappingService.mappingActivity.as_view({'get': 'Mapping'})), 
    # path('classification', activityMappingService.levelClasification.as_view({'post': 'classification'})),
    path('sustainability_add', activityMappingService.sustainabilityActivity.as_view({'post': 'sustainability_add'})),
    path('sustainability_view', activityMappingService.sustainabilityActivity.as_view({'get': 'sustainability_view'})),
    # path('insert', nece_mapping.Insert_data),
    # path('ref_insert', nece_mapping.Insert_ref_data),
    path('', include(router.urls)),
]