from django.urls import path, include
from repository.apiRepository import ApiAvarni
from api_config import avarni_api
from rest_framework import routers

router = routers.SimpleRouter()


urlpatterns = [
    path('calculate',ApiAvarni.as_view({'get': 'api_avarni'})),
    path('token',ApiAvarni.as_view({'get': 'basic_token'})),
    path('', include(router.urls)),
]