from django.urls import path
from esg_app import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('category',views.categoryAPI.as_view({'get':'company_api'}))
]
