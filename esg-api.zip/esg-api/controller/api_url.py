from django.urls import path, include
from repository import apiRepository

urlpatterns = [
    path('api', apiRepository.ApiAvarni.as_view({'get': 'api_avarni'}))
]