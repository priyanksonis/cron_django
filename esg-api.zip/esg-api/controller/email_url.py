from django.urls import path
from service import authService, emailService


urlpatterns = [
    path('otp', emailService.OTPRepo.as_view()),
]