from django.urls import path, include
from service import activityMappingService
from rest_framework import routers
from activity_mapping import sustainability_mapping, nece_mapping
from repository import newsArticles

router = routers.SimpleRouter()
# router.register('api/V1/company', companyService.CompanyRepository, basename='company')
# urlpatterns = router.urls


urlpatterns = [
    path('news_articles', newsArticles.NewsArticleRepo.as_view({'get': 'get_news_letter'})),
    path('', include(router.urls)),
]